java -Xms8g -Xmx8g -cp minim.jar:jsminim.jar:jl1.0.1.jar:mp3spi1.9.5.jar:tritonus_aos.jar:tritonus_share.jar:dragons_of_ballpit.jar org.rajatietotekniikka.dragonsofballpit.Demo

